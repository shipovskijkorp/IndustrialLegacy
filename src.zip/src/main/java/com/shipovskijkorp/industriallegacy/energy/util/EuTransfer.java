package com.shipovskijkorp.industriallegacy.energy.util;

import com.shipovskijkorp.industriallegacy.energy.api.IEuEnergyStorage;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;


public final class EuTransfer {
    private EuTransfer() {}

    /**
     * Legacy helper used by older call sites.
     *
     * <p>Attempts to extract up to {@code maxAmount} EU from the storage at {@code pos}.
     * The {@code side} parameter is interpreted as the side of the <em>target</em> storage.
     */
    public static long tryExtract(World world, BlockPos pos, Direction side, long maxAmount, boolean simulate) {
        if (maxAmount <= 0L) return 0L;

        IEuEnergyStorage storage = getStorage(world, pos);
        if (storage == null) return 0L;
        if (!storage.canExtract(side)) return 0L;

        return storage.extractEu(maxAmount, side, simulate);
    }

    /**
     * Legacy helper used by older call sites.
     *
     * <p>Attempts to insert {@code amount} EU into the storage at {@code pos}.
     * The {@code side} parameter is interpreted as the side of the <em>target</em> storage.
     */
    public static long tryInsert(World world, BlockPos pos, Direction side, long amount, boolean simulate) {
        if (amount <= 0L) return 0L;

        IEuEnergyStorage storage = getStorage(world, pos);
        if (storage == null) return 0L;
        if (!storage.canInsert(side)) return 0L;

        return storage.insertEu(amount, side, simulate);
    }

    /**
     * Get an {@link IEuEnergyStorage} at the position, if any.
     */
    public static IEuEnergyStorage getStorage(World world, BlockPos pos) {
        BlockEntity be = world.getBlockEntity(pos);
        return (be instanceof IEuEnergyStorage s) ? s : null;
    }

    /**
     * Try to inject energy into a neighbor tile.
     *
     * @param fromPos origin block position
     * @param dir     direction towards the neighbor
     * @param amount  amount to inject (EU)
     * @param voltageTier voltage tier used for overvoltage checks
     * @param simulate if true, don't change state
     * @return amount that was accepted (EU)
     */
    public static double tryInjectNeighbor(World world, BlockPos fromPos, Direction dir, double amount, int voltageTier, boolean simulate) {
        if (amount <= 0.0) return 0.0;

        BlockPos toPos = fromPos.offset(dir);
        IEuEnergyStorage storage = getStorage(world, toPos);
        if (storage == null) return 0.0;

        Direction fromSide = dir.getOpposite();
        if (!storage.canInsert(fromSide)) return 0.0;

        double rejected = storage.injectEnergy(fromSide, amount, voltageTier, simulate);
        return Math.max(0.0, amount - rejected);
    }

    /**
     * Try to extract energy from a neighbor tile.
     *
     * @return amount extracted (EU)
     */
    public static double tryExtractNeighbor(World world, BlockPos fromPos, Direction dir, double amount, boolean simulate) {
        if (amount <= 0.0) return 0.0;

        BlockPos toPos = fromPos.offset(dir);
        IEuEnergyStorage storage = getStorage(world, toPos);
        if (storage == null) return 0.0;

        Direction toSide = dir.getOpposite();
        if (!storage.canExtract(toSide)) return 0.0;

        return storage.drawEnergy(amount, simulate);
    }
}
